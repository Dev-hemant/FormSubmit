import CompanySalary from './Components/CompanySalary';

function App() {
  return (<CompanySalary />);
}

export default App;
